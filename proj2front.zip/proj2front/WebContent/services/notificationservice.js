/**
 * 
 */
app.factory('NotificationService',function($http){
	var notificationService={}
	
	notificationService.getNotificationsNotViewed=function(){
		return $http.get("http://localhost:8081/proj2mid/getnotifications")
	}
	
	notificationService.getNotification=function(id){
		return $http.get("http://localhost:8081/proj2mid/getnotification/"+id)
	}
	
	notificationService.updateNotification=function(id){
		return $http.put("http://localhost:8081/proj2mid/updatenotification/"+id)
	}
	
	return notificationService;
})