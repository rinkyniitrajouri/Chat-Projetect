/**
 *  User Service to makeserver side calls
 */

app.factory('UserService',function($http){
	var userService={}
	
	userService.registerUser=function(user){
		alert('entering userservice registeruser function')
	//format of user-JSON 
	console.log('in userservice')
	console.log(user)	
	return $http.post("http://localhost:8081/proj2mid/registeruser",user)
	}
	
	userService.login=function(user){
		console.log('userservice -> login')
		console.log(user)
		return $http.post("http://localhost:8081/proj2mid/login",user)
	}
	
	userService.logout=function(){
		return $http.put("http://localhost:8081/proj2mid/logout")
	}
	
	userService.getUser=function(){
		return $http.get("http://localhost:8081/proj2mid/getuser")
	}
	
	userService.updateUser=function(user){
		return $http.put("http://localhost:8081/proj2mid/updateuser",user)
	}
	
	userService.searchUser=function(user){
		return $http.get("http://localhost:8081/proj2mid/searchuser/"+user)
	}
	
	return userService;
	
})