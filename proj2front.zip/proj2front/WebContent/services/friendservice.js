/**
 * 
 */
app.factory('FriendService',function($http){
	var friendService={}
	
	friendService.getAllSuggestedUsers=function(){
		return $http.get("http://localhost:8081/proj2mid/suggestedusers")
	}
	friendService.addFriend=function(toId){
		return $http.post("http://localhost:8081/proj2mid/addfriend",toId)
	}
	
	friendService.getPendingRequests=function(){
		return $http.get("http://localhost:8081/proj2mid/pendingrequests")
	}
	
	friendService.acceptRequest=function(request){
		return $http.put("http://localhost:8081/proj2mid/acceptrequest",request)
	}
	
	friendService.deleteRequest=function(request){
		return $http.put("http://localhost:8081/proj2mid/deleterequest",request)
	}
	
	friendService.getAllFriends=function(){
		return $http.get("http://localhost:8081/proj2mid/friends")
	}
	
	return friendService;
})