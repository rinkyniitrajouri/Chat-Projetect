package com.dao;

import com.model.ProfilePicture;

public interface ProfilePictureDao {

	void uploadProfilePicture(ProfilePicture profilePicture);

	ProfilePicture getImage(String email);
}
